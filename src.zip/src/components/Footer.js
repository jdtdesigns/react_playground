function Footer(props) {
  return (
    <footer>
      <p>{props.logo}</p>
    </footer>
  );
}

export default Footer;