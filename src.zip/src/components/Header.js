function Header(propsObj) {

  return (
    <header>
      <h3>{propsObj.logo} &#128034;</h3>

      <p>Header Count Output: {propsObj.count}</p>
    </header>
  )
}

export default Header;