import { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  const logo = 'Turtle App';
  const [count, setCount] = useState(0);


  return (
    <>
      <Header count={count} logo={logo} another={'some other val'} />

      <h1>Welcome to our app. Let's learn about turtles!</h1>
      Count: {count}

      <button onClick={() => setCount(count + 1)}>Increase Count</button>
      <Footer logo={logo} />
    </>
  );
}

export default App;


